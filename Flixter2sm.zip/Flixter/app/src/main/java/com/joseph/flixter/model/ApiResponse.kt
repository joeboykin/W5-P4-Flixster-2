package com.joseph.flixter.model

import com.google.gson.annotations.SerializedName

data class ApiResponse(
    val page: Int,
    val results: List<HomeDataModel>,
    @SerializedName("total_pages")
    val totalPages: Int,
    @SerializedName("total_results")
    val totalResults: Int
)

