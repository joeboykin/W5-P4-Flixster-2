package com.joseph.flixter

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.joseph.flixter.adapter.TopAdapter
import com.joseph.flixter.model.ApiResponse
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private lateinit var movieAdapter: TopAdapter
    private lateinit var tvAdapter: TopAdapter
    private lateinit var scope: CoroutineScope

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize RecyclerViews and adapters
        val movieRecyclerView: RecyclerView = findViewById(R.id.most_popular_movies_recycler_view)
        val tvRecyclerView: RecyclerView = findViewById(R.id.most_popular_tv_shows_recycler_view)

        //Init empty Adapters
        movieAdapter = TopAdapter(this, mutableListOf())
        tvAdapter = TopAdapter(this, mutableListOf())

        val apiKey = "a07e22bc18f5cb106bfe4cc1f83ad8ed"

        //Set Horizontal Layout
        movieRecyclerView.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tvRecyclerView.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        movieRecyclerView.adapter = movieAdapter
        tvRecyclerView.adapter = tvAdapter

        // Make API calls to get top movies and top TV shows this week
        val queue = Volley.newRequestQueue(this)
        val movieUrl =
            "https://api.themoviedb.org/3/movie/popular?api_key=$apiKey&language=en-US&page=1"
        val tvUrl = "https://api.themoviedb.org/3/tv/popular?api_key=$apiKey&language=en-US&page=1"


// Use coroutines to make API calls and update the UI
        scope = CoroutineScope(Dispatchers.Main)

// Use coroutines to make API calls and update the UI
        scope.launch {
            // Launch two separate coroutines to make the API calls
            val movieDeferred = async(Dispatchers.IO) {
                val movieRequest = StringRequest(
                    Request.Method.GET, movieUrl,
                    { response ->
                        val gson = Gson()
                        val movieResponse = gson.fromJson(response, ApiResponse::class.java)
                        movieAdapter.data = movieResponse.results
                        movieAdapter.notifyDataSetChanged()
                    },
                    { error ->
                        Log.e("TAG", "Error getting top movies this week", error)
                    })
                queue.add(movieRequest)
            }
            val tvDeferred = async(Dispatchers.IO) {
                val tvRequest = StringRequest(Request.Method.GET, tvUrl,
                    { response ->
                        val gson = Gson()
                        val tvResponse = gson.fromJson(response, ApiResponse::class.java)
                        tvAdapter.data = tvResponse.results
                        tvAdapter.notifyDataSetChanged()
                    },
                    { error ->
                        Log.e("TAG", "Error getting top TV shows this week", error)
                    })
                queue.add(tvRequest)
            }
            // Wait for both coroutines to complete and get their results
            movieDeferred.await()
            tvDeferred.await()
        }


    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
