package com.joseph.flixter.model

import com.google.gson.annotations.SerializedName

data class HomeDataModel(
    val title:String,
    @SerializedName("poster_path")
    val image:String,
    @SerializedName("backdrop_path")
    val backdrop:String,
    @SerializedName("overview")
    val description:String,
    @SerializedName("first_air_date")
    val firstAirDate:String,
   )
