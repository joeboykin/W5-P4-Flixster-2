package com.joseph.flixter

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class DetailsActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MOVIE = "extra_movie"
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        val bundle = intent.getBundleExtra(EXTRA_MOVIE)

        val description = bundle!!.getString("Desc")
        val title = bundle.getString("Title")
        val poster = bundle.getString("Poster")
        val airDate = bundle.getString("AirDate")

        val imageView: ImageView = findViewById(R.id.imageView)
        val titleTextView: TextView = findViewById(R.id.titleTextView)
        val firstAirDateTextView: TextView = findViewById(R.id.firstAirDateTextView)
        val descriptionTextView: TextView = findViewById(R.id.descriptionTextView)

        Glide.with(this)
            .load("https://image.tmdb.org/t/p/w500${poster}")
            .error(R.drawable.baseline_error_24)
            .into(imageView)

        titleTextView.text = title
        firstAirDateTextView.text = "First Air Date: ${airDate}"
        descriptionTextView.text = description

    }
}
