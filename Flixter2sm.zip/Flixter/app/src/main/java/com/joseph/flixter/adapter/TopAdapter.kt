package com.joseph.flixter.adapter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.joseph.flixter.DetailsActivity
import com.joseph.flixter.R
import com.joseph.flixter.model.HomeDataModel

class TopAdapter(private val context: Context, var data: List<HomeDataModel>) :
    RecyclerView.Adapter<TopAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val moviePosterImageView: ImageView = itemView.findViewById(R.id.movie_poster_image_view)
        val movieTitleTextView: TextView = itemView.findViewById(R.id.movie_title_text_view)


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_poster, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val movie = data[position]
        Glide.with(context)
            .load("https://image.tmdb.org/t/p/original"+movie.image)
            .transform(RoundedCorners(16)) // Apply rounded corner transformation
            .into(holder.moviePosterImageView)
        holder.movieTitleTextView.text = movie.title


        // Set click listener on item view
        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, DetailsActivity::class.java)
            val bundle = Bundle()
            bundle.putString("Title", movie.title)
            bundle.putString("Desc", movie.description)
            bundle.putString("Poster", movie.backdrop)
            bundle.putString("AirDate", movie.firstAirDate)

            intent.putExtra(DetailsActivity.EXTRA_MOVIE, bundle)
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }
}
